"""
Day 18 tests. Run offline:   python -m unittest test_ai_web_integration -v
Optional live consistency test against the deployed API:
    set HISABDO_AI_URL=https://<your-render-url>/api/ai/explain   (then run again)
"""
import copy
import json
import os
import unittest
import urllib.request
from pathlib import Path

import ai_web_validator as v

CTX = json.loads((Path(__file__).parent / "sample_verified_context.json").read_text())


def fake_grounded_ai(ctx):
    """Deterministic stand-in for the LLM: only quotes verified numbers."""
    r = ctx["recommendations"][0]
    return (f"Your saving rate is {ctx['savingRate']}%. {r['action']} "
            f"Food spending is {ctx['spendingPatterns'][0]['currentAmount']:,}.")


def fake_hallucinating_ai(ctx):
    return "Your saving rate is 8.5% and you will save Rs 99,999 next month."


class TestModuleValidation(unittest.TestCase):
    def test_sample_context_is_valid(self):
        for r in v.validate_context(CTX):
            self.assertTrue(r.is_valid, r.to_dict())

    def test_health_score_range(self):
        bad = {**CTX, "healthScore": 140}
        self.assertFalse(v.validate_financial_health(bad).is_valid)

    def test_spending_change_mismatch(self):
        p = {**CTX["spendingPatterns"][0], "changePercent": 80}
        self.assertFalse(v.validate_spending_pattern(p).is_valid)

    def test_anomaly_unverified_rejected(self):
        a = {**CTX["anomalies"][0], "isVerified": False}
        self.assertFalse(v.validate_anomaly(a).is_valid)

    def test_forecast_math(self):
        f = {**CTX["forecasts"][0], "expectedSaving": 5}
        self.assertFalse(v.validate_forecast(f).is_valid)

    def test_forecast_missing_closing_balance_is_warning_only(self):
        r = v.validate_forecast(CTX["forecasts"][0])
        self.assertTrue(r.is_valid)
        self.assertTrue(r.warnings)

    def test_budget_negative(self):
        b = {**CTX["budgetRecommendations"][0], "recommendedBudget": -1}
        self.assertFalse(v.validate_budget_recommendation(b).is_valid)

    def test_priority_severity_values(self):
        r = {**CTX["recommendations"][0], "priority": "Urgent"}
        self.assertFalse(v.validate_recommendation(r).is_valid)
        r = {**CTX["recommendations"][0], "severity": "Extreme"}
        self.assertFalse(v.validate_recommendation(r).is_valid)

    def test_priority_order(self):
        low = {**CTX["recommendations"][0], "priority": "Low", "severity": "Low"}
        high = CTX["recommendations"][0]
        self.assertTrue(v.validate_priority_order([high, low]).is_valid)
        self.assertFalse(v.validate_priority_order([low, high]).is_valid)

    def test_unverified_benefit_must_be_hidden(self):
        r = {**CTX["recommendations"][0], "expectedBenefit": 5000, "expectedBenefitVerified": False}
        self.assertFalse(v.validate_recommendation(r).is_valid)


class TestAntiHallucination(unittest.TestCase):
    def test_grounded_answer_passes(self):
        self.assertTrue(v.validate_ai_answer(fake_grounded_ai(CTX), CTX).is_valid)

    def test_invented_number_is_blocked(self):
        res = v.validate_ai_answer(fake_hallucinating_ai(CTX), CTX)
        self.assertFalse(res.is_valid)

    def test_unverified_record_numbers_do_not_count(self):
        ctx = copy.deepcopy(CTX)
        ctx["anomalies"][0]["isVerified"] = False
        self.assertIn(30000.0, v.find_unverified_numbers("Anomaly of Rs 30,000", ctx))

    def test_gatekeeper_blocks_hallucination(self):
        out = v.safe_answer(CTX, fake_hallucinating_ai)
        self.assertFalse(out["isVerified"])
        self.assertEqual(out["answer"], v.INSUFFICIENT_DATA_MESSAGE)


class TestMissingData(unittest.TestCase):
    EMPTY = {"userId": "user-002", "recommendations": [], "spendingPatterns": [],
             "anomalies": [], "budgetRecommendations": [], "forecasts": []}

    def test_empty_context_does_not_call_ai(self):
        called = []
        out = v.safe_answer(self.EMPTY, lambda c: called.append(1) or "x")
        self.assertEqual(called, [])
        self.assertFalse(out["isVerified"])
        self.assertEqual(out["answer"], v.INSUFFICIENT_DATA_MESSAGE)

    def test_partial_data_still_answers(self):
        ctx = {**self.EMPTY, "healthScore": 70}
        out = v.safe_answer(ctx, lambda c: "Your financial health score is 70.")
        self.assertTrue(out["isVerified"])


class TestConsistency(unittest.TestCase):
    RUNS = 5

    def test_offline_consistency(self):
        """Same verified input must always give the same numbers."""
        sets = [frozenset(v.extract_financial_numbers(fake_grounded_ai(CTX)))
                for _ in range(self.RUNS)]
        self.assertEqual(len(set(sets)), 1)

    @unittest.skipUnless(os.getenv("HISABDO_AI_URL"), "set HISABDO_AI_URL for live test")
    def test_live_consistency(self):
        url = os.environ["HISABDO_AI_URL"]
        payload = json.dumps({"userId": CTX["userId"],
                              "question": "Why is my financial health score low?",
                              "context": CTX}).encode()
        answers = []
        for _ in range(self.RUNS):
            req = urllib.request.Request(url, payload, {"Content-Type": "application/json"})
            answers.append(json.load(urllib.request.urlopen(req, timeout=60))["answer"])
        for a in answers:
            self.assertTrue(v.validate_ai_answer(a, CTX).is_valid, a)
        number_sets = {frozenset(v.extract_financial_numbers(a)) for a in answers}
        print("\nDistinct number-sets across runs:", len(number_sets))
        # Wording may differ; every number must stay inside verified data (checked above).


if __name__ == "__main__":
    unittest.main(verbosity=2)
