# HisabDo - Day 18: AI / Data Integration (Web Application)

**Task:** AI / Data Integration (subtask of AIML-day-18-Task)
**Scope:** Define, validate and document the AI data that the HisabDo web application consumes.
**Source of truth reviewed:** Day 11 to Day 17 services and specifications in `HisabDo-MobieAppAI`, and the Python explanation service (`HisabDo_Python_Integration_FastAPI.py`).

## Guiding Principle

The .NET backend owns every financial calculation. The AI layer only explains verified results. The web application only displays them.

- The backend produces scores, amounts, percentages, forecasts, priority and severity.
- The AI layer receives only records with `isVerified = true` and never recalculates or invents values.
- The web application never changes a backend value; it renders values and explanations.

Data flow: **Backend engines -> Verified context (JSON) -> AI explanation layer -> Validation gate -> Web application**

---

## 1. AI Data Required by the Web Application

| Module | Purpose on web | Source (Day) |
|---|---|---|
| Financial Health | Score gauge and classification | Day 10 / 15 |
| Spending Patterns | Category trends and changes | Day 11 |
| Anomalies | Unusual transaction alerts | Day 12 |
| Cash-Flow Forecast | Expected income, expense, saving | Day 13 |
| Budget Recommendations | Suggested category budgets | Day 14 |
| Recommendation Engine | Prioritized action list | Day 16 |
| AI Explanations | Plain-language text per module | Day 11 to 16 |
| Limitations / Data Availability | Explain what is missing | All |

Every record carries `isVerified`. Records with `isVerified = false` are never displayed and never sent to the AI.

## 2. Financial Health Data

| Field | Type | Rule |
|---|---|---|
| `healthScore` | number | Required, 0 to 100 |
| `savingRate` | number (%) | Optional; if null, not mentioned |
| `expenseGrowthPercent` | number (%) | Optional; if null, not mentioned |
| `cashFlow` | number | Optional |
| `cashFlowRisk` | string | Optional |

The web app displays the backend score as is. The AI explanation must not compute a new score. If `healthScore` is missing, the health card shows "Financial health is not available yet."

## 3. Spending Pattern Data

| Field | Type | Rule |
|---|---|---|
| `category` | string | Required |
| `currentAmount` | number | Required, >= 0 |
| `previousAmount` | number or null | If null or 0, percentage is not displayed |
| `changePercent` | number or null | Must match `(current - previous) / previous * 100` within 0.5 |
| `direction` | Increasing / Decreasing / Stable | Required |
| `isVerified` | bool | Must be true |

## 4. Anomaly Data

| Field | Type | Rule |
|---|---|---|
| `id` | string | Required |
| `type` | UnusualAmount / SuddenSpendingSpike / UnusualCategory / DuplicateTransaction | Required |
| `category` | string | Required |
| `amount` | number | Required, >= 0 |
| `severity` | Low / Medium / High (/ Critical) | Required, backend value |
| `reason` | string | Required, backend text |
| `isVerified` | bool | Must be true |

## 5. Cash-Flow Forecast Data

| Field | Type | Rule |
|---|---|---|
| `period` | string (YYYY-MM) | Required |
| `forecastIncome` / `forecastExpense` | number | Required for display |
| `expectedSaving` | number | Must equal income minus expense |
| `expectedClosingBalance` | number or null | Null when no trusted opening balance exists; web shows "Unavailable" |
| `confidence` | Low / Medium / High | Required |

Confidence follows the Day 13 rule: fewer than the minimum history months gives Low; the preferred history with no empty months gives High; otherwise Medium.

## 6. Budget Recommendation Data

| Field | Type | Rule |
|---|---|---|
| `category` | string | Required |
| `historicalAverage` | number | Required |
| `recommendedBudget` | number | Required, >= 0 |
| `existingBudget` | number or null | If null, variance is not shown |
| `reason` | string | Required, backend text |
| Data sufficiency | Sufficient / Limited | Limited when less than the preferred history is available (Day 14) |

## 7. Recommendation Engine Data

| Field | Type | Rule |
|---|---|---|
| `id`, `type`, `reason`, `action` | string | Required |
| `priority` | Low / Medium / High | Required |
| `severity` | Low / Medium / High / Critical | Required |
| `expectedBenefit` | number or null | Shown only if `expectedBenefitVerified = true` |
| `isVerified` | bool | Must be true |

## 8. Recommendation Priority and Severity

Priority and severity are assigned by the backend engine (Day 16 thresholds: saving rate below 10%, expense growth 20% or more, budget utilization 120% and 150%).

Rules for the web application:

1. Only these values are valid: priority `Low | Medium | High`, severity `Low | Medium | High | Critical`. Anything else is rejected.
2. The list is displayed in backend order: priority (High first), then severity (Critical first), then category.
3. The AI and the web app never re-rank, upgrade or downgrade a recommendation.

## 9. AI Explanations Use Verified Backend Data

1. The web sends only the authenticated user's verified context; `userId` in the request must equal `userId` in the context (403 otherwise).
2. The service filters out every record where `isVerified = false` before building the prompt.
3. The prompt states that the AI must use only supplied values and must not recalculate.
4. Every AI answer passes the validation gate (`validate_ai_answer`) before display.

## 10. AI Must Not Invent Financial Numbers

Enforced in two layers:

- **Prompt layer:** the system prompt forbids inventing any amount, percentage, score, forecast, priority, severity or benefit.
- **Code layer:** `find_unverified_numbers()` extracts financial numbers from the AI answer (percentages, currency values, and plain numbers of 100 or more) and compares them to numbers in verified records. Any unmatched number rejects the answer and the web shows the safe fallback message.

## 11. Sample AI Responses for Web

Verified context: `sample_verified_context.json`.

**Question:** "Why is my financial health score low?"
**Valid answer:** "Your financial health score is 58, which is below the level we consider healthy. Your saving rate is 8.5% and your expenses grew by 22.4%. Reviewing your high-spending categories is the suggested next step."
Result: **accepted** (58, 8.5 and 22.4 are all in verified data).

**Question:** "How much will I save next month?"
**Valid answer:** "Your forecast for 2026-10 shows an expected saving of 12,000, with Medium confidence. The closing balance is unavailable because no trusted opening balance was supplied."
Result: **accepted**.

**Invalid answer (blocked):** "You will save Rs 99,999 next month."
Result: **rejected**, 99,999 is not in verified data. Web shows: "There is not enough verified data to answer this reliably yet."

## 12. Missing / Insufficient Data Behavior

| Situation | Backend signal | Web behavior |
|---|---|---|
| No verified data at all | All modules missing | Show fixed fallback message; AI is not called |
| One module missing | Module marked `missing` | Hide that card, show "Not available yet"; AI must not mention it |
| No anomalies found | Empty list | Show "No unusual activity detected" |
| No trusted opening balance | `expectedClosingBalance = null` | Show "Unavailable" |
| Less than preferred history | Sufficiency = Limited / Confidence = Low | Show value with a "Limited data" label |
| No previous amount | `previousAmount` null or 0 | Do not display percentage change |
| Record not verified | `isVerified = false` | Hide record; never send to AI |
| AI service failure | HTTP 502 | Show data cards without AI text and a retry option |

## 13. AI Response Consistency Testing

Wording from an LLM can vary; numbers must not. The test suite checks:

- Same verified input always produces the same set of financial numbers (offline test with a deterministic stand-in).
- Live test (optional): calls the deployed endpoint 5 times with the same context, verifies every answer passes the number-grounding check, and prints how many distinct number sets were returned.

Run: `python -m unittest test_ai_web_integration -v`
Result of the offline run: 18 tests, all passing, 1 live test skipped unless `HISABDO_AI_URL` is set.

## 14. AI-to-Web Data Mapping

| AI / Backend field | Web component | Display rule |
|---|---|---|
| `healthScore` | Health gauge | Number as is; never recomputed |
| `savingRate`, `expenseGrowthPercent` | Health detail chips | Hidden if null |
| `spendingPatterns[].category / currentAmount` | Spending table | Formatted currency |
| `spendingPatterns[].changePercent / direction` | Trend badge | Hidden if no previous amount |
| `anomalies[].severity` | Alert badge color | Low, Medium, High, Critical |
| `anomalies[].reason` | Alert text | Backend text as is |
| `forecasts[].forecastIncome / forecastExpense / expectedSaving` | Forecast card | Formatted currency |
| `forecasts[].expectedClosingBalance` | Forecast card | "Unavailable" if null |
| `forecasts[].confidence` | Confidence tag | Low, Medium, High |
| `budgetRecommendations[]` | Budget table | Variance hidden if no existing budget |
| `recommendations[].priority / severity` | Recommendation list | Backend order; badges from values |
| `recommendations[].action` | Action text | Backend text as is |
| `limitations` | Info banner | Shown whenever not empty |
| AI `answer` | Explanation panel | Shown only after validation gate passes |
| AI `isVerified = false` | Explanation panel | Replace with fallback message |

---

## Observations From the Repository Review

These are gaps found while reviewing the code. They are worth fixing or confirming with the team before the web integration goes live.

1. **Two different AI endpoints exist.** Root `main.py` (deployed on Render) exposes `/api/explain` with a company-style payload (`company_name`, `revenue`, `profit`, `financial_score`). The personal-finance schema used by the web (`userId`, `context`, `healthScore`, and so on) is in `HisabDo_Python_Integration_FastAPI.py` at `/api/ai/explain`. The web app should target the second schema, so the deployed service needs to expose it.
2. **The mobile validator's number check is a stub.** `ContainsUnverifiedFinancialNumber` in the Day 17 mobile validation code always returns `false`, so it cannot block invented numbers. The Python `find_unverified_numbers()` in this submission implements a working check.
3. **Enum mismatch between Day 12 and Day 16.** Anomaly severity in Day 12 has Low, Medium, High, while recommendation severity has a fourth level, Critical. The web should accept all four.
4. **Two recommendation type lists.** `Forecasting/RecommendationModels.cs` and the Day 16 engine define different `RecommendationType` values. The web should render the `type` as a string and not assume a fixed list until the team confirms one.
5. **Two budget sufficiency vocabularies.** `BudgetAnalysisService` returns `insufficient_data` / `ready`, while `BudgetRecommendationService` returns `Limited` / `Sufficient`. The web needs one agreed mapping.
6. **Financial Health classification bands** (for example, what score range is "Good" or "Poor") were not found in the repository. The web should display the backend `classification` and not define its own bands.

## Deliverable Files

- `Day18_AI_Data_Integration.md` (this document)
- `ai_web_validator.py` (validation and safety gate)
- `test_ai_web_integration.py` (18 tests)
- `sample_verified_context.json` (sample verified backend data)
