"""
HisabDo - Day 18: AI / Data Integration (web application)
Validation layer for AI data before it is shown on the web app.

Golden rule: the backend owns every financial number, score, priority and
severity. The AI layer only explains them. The web app only displays them.

Field names follow the Day 16 AI explanation service (camelCase JSON).
Standard library only, so it runs anywhere.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

ALLOWED_PRIORITY = {"Low", "Medium", "High"}
ALLOWED_SEVERITY = {"Low", "Medium", "High", "Critical"}
ALLOWED_TREND = {"Increasing", "Decreasing", "Stable"}
ALLOWED_CONFIDENCE = {"Low", "Medium", "High"}
ALLOWED_SUFFICIENCY = {"Sufficient", "Limited", "Insufficient"}

# Financial number types the AI text is never allowed to invent.
INSUFFICIENT_DATA_MESSAGE = (
    "There is not enough verified data to answer this reliably yet."
)


@dataclass
class ValidationResult:
    module: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "module": self.module,
            "isValid": self.is_valid,
            "errors": self.errors,
            "warnings": self.warnings,
        }


# ---------------------------------------------------------------- helpers
def _missing(record: dict, key: str) -> bool:
    v = record.get(key)
    return v is None or (isinstance(v, str) and not v.strip())


def _require(record: dict, keys: Iterable[str], res: ValidationResult, label: str):
    for k in keys:
        if _missing(record, k):
            res.errors.append(f"{label}: required field '{k}' is missing or empty.")


def _is_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


# ------------------------------------------------- 2. Financial Health
def validate_financial_health(ctx: dict) -> ValidationResult:
    res = ValidationResult("financial_health")
    score = ctx.get("healthScore")
    if score is None:
        res.errors.append("healthScore is missing.")
    elif not _is_number(score) or not 0 <= score <= 100:
        res.errors.append("healthScore must be a number between 0 and 100.")
    for k in ("savingRate", "expenseGrowthPercent"):
        if ctx.get(k) is None:
            res.warnings.append(f"{k} is unavailable; explanation must not mention it.")
    return res


# ------------------------------------------------- 3. Spending Pattern
def validate_spending_pattern(p: dict) -> ValidationResult:
    res = ValidationResult("spending_pattern")
    _require(p, ("category", "direction"), res, "SpendingPattern")
    if not p.get("isVerified"):
        res.errors.append("SpendingPattern is not verified.")
    if not _is_number(p.get("currentAmount")) or p.get("currentAmount", 0) < 0:
        res.errors.append("currentAmount must be a non-negative number.")
    if p.get("direction") and p["direction"] not in ALLOWED_TREND:
        res.errors.append(f"direction must be one of {sorted(ALLOWED_TREND)}.")
    prev = p.get("previousAmount")
    if prev in (None, 0):
        if p.get("changePercent") not in (None, 0):
            res.warnings.append(
                "changePercent exists but previousAmount is missing/zero; do not display it."
            )
    else:
        expected = (p["currentAmount"] - prev) / prev * 100
        if p.get("changePercent") is not None and abs(expected - p["changePercent"]) > 0.5:
            res.errors.append(
                f"changePercent {p['changePercent']} does not match amounts (expected ~{expected:.1f})."
            )
    return res


# ------------------------------------------------------- 4. Anomaly
def validate_anomaly(a: dict) -> ValidationResult:
    res = ValidationResult("anomaly")
    _require(a, ("id", "type", "category", "severity", "reason"), res, "Anomaly")
    if not a.get("isVerified"):
        res.errors.append("Anomaly is not verified.")
    if not _is_number(a.get("amount")) or a.get("amount", 0) < 0:
        res.errors.append("Anomaly amount must be a non-negative number.")
    if a.get("severity") and a["severity"] not in ALLOWED_SEVERITY:
        res.errors.append(f"Anomaly severity must be one of {sorted(ALLOWED_SEVERITY)}.")
    return res


# ---------------------------------------------- 5. Cash-Flow Forecast
def validate_forecast(f: dict) -> ValidationResult:
    res = ValidationResult("cash_flow_forecast")
    _require(f, ("period", "confidence"), res, "Forecast")
    if not f.get("isVerified"):
        res.errors.append("Forecast is not verified.")
    if f.get("confidence") and f["confidence"] not in ALLOWED_CONFIDENCE:
        res.errors.append(f"confidence must be one of {sorted(ALLOWED_CONFIDENCE)}.")
    inc, exp, sav = f.get("forecastIncome"), f.get("forecastExpense"), f.get("expectedSaving")
    if None in (inc, exp, sav):
        res.warnings.append("Forecast income/expense/saving is incomplete.")
    elif abs((inc - exp) - sav) > 1:
        res.errors.append("expectedSaving must equal forecastIncome - forecastExpense.")
    if f.get("expectedClosingBalance") is None:
        res.warnings.append(
            "expectedClosingBalance is unavailable (no trusted opening balance); web must show 'Unavailable'."
        )
    return res


# ------------------------------------------- 6. Budget Recommendation
def validate_budget_recommendation(b: dict) -> ValidationResult:
    res = ValidationResult("budget_recommendation")
    _require(b, ("category", "reason"), res, "BudgetRecommendation")
    if not b.get("isVerified"):
        res.errors.append("BudgetRecommendation is not verified.")
    if not _is_number(b.get("recommendedBudget")) or b.get("recommendedBudget", -1) < 0:
        res.errors.append("recommendedBudget must be a non-negative number.")
    if not _is_number(b.get("historicalAverage")):
        res.errors.append("historicalAverage is required.")
    if b.get("existingBudget") is None:
        res.warnings.append("No existing budget; do not show variance.")
    return res


# ------------------------------------------ 7 + 8. Recommendation Engine
def validate_recommendation(r: dict) -> ValidationResult:
    res = ValidationResult("recommendation")
    _require(r, ("id", "type", "reason", "action", "priority"), res, "Recommendation")
    if not r.get("isVerified"):
        res.errors.append("Recommendation is not verified.")
    if r.get("priority") not in ALLOWED_PRIORITY:
        res.errors.append(f"priority must be one of {sorted(ALLOWED_PRIORITY)}.")
    sev = r.get("severity")
    if sev is None:
        res.warnings.append("severity is missing.")
    elif sev not in ALLOWED_SEVERITY:
        res.errors.append(f"severity must be one of {sorted(ALLOWED_SEVERITY)}.")
    if r.get("expectedBenefit") is not None and not r.get("expectedBenefitVerified"):
        res.errors.append("expectedBenefit is present but not verified; it must be hidden.")
    return res


def validate_priority_order(recs: list[dict]) -> ValidationResult:
    """Web must show recommendations in backend order: priority, then severity."""
    res = ValidationResult("recommendation_order")
    p_rank = {"High": 1, "Medium": 2, "Low": 3}
    s_rank = {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}
    keys = [(p_rank.get(r.get("priority"), 9), s_rank.get(r.get("severity"), 9)) for r in recs]
    if keys != sorted(keys):
        res.errors.append("Recommendations are not ordered by priority then severity.")
    return res


# ------------------------------------------------ full context checker
def validate_context(ctx: dict) -> list[ValidationResult]:
    out = [validate_financial_health(ctx)]
    out += [validate_spending_pattern(x) for x in ctx.get("spendingPatterns", [])]
    out += [validate_anomaly(x) for x in ctx.get("anomalies", [])]
    out += [validate_forecast(x) for x in ctx.get("forecasts", [])]
    out += [validate_budget_recommendation(x) for x in ctx.get("budgetRecommendations", [])]
    recs = ctx.get("recommendations", [])
    out += [validate_recommendation(x) for x in recs]
    out.append(validate_priority_order(recs))
    return out


# ------------------------- 9 + 10. AI must not invent financial numbers
def collect_verified_numbers(ctx: dict) -> set[float]:
    """Every number found in verified records of the context."""
    nums: set[float] = set()

    def walk(node: Any, verified: bool = True):
        if isinstance(node, dict):
            if node.get("isVerified") is False:
                return  # unverified records never count as truth
            for k, v in node.items():
                if k == "userId":
                    continue
                walk(v, verified)
        elif isinstance(node, list):
            for v in node:
                walk(v, verified)
        elif _is_number(node):
            nums.add(float(node))

    walk(ctx)
    return nums


_NUM = re.compile(r"(?<![\w.])(?:(?:Rs\.?|PKR|\$)\s*)?(\d[\d,]*(?:\.\d+)?)(\s*%)?", re.I)


def extract_financial_numbers(text: str) -> list[float]:
    """
    Numbers that look financial: percentages, currency-prefixed values,
    or plain numbers >= 100. Small counts ("3 months", "2 categories") and
    year-month tokens are ignored to avoid false alarms.
    """
    found: list[float] = []
    for m in _NUM.finditer(text or ""):
        raw, pct = m.group(1), m.group(2)
        val = float(raw.replace(",", ""))
        is_currency = bool(re.match(r"(Rs|PKR|\$)", m.group(0), re.I))
        if pct or is_currency or val >= 100:
            if 1900 <= val <= 2100 and not pct and not is_currency:
                continue  # looks like a year
            found.append(val)
    return found


def find_unverified_numbers(text: str, ctx: dict, tol: float = 0.01) -> list[float]:
    verified = collect_verified_numbers(ctx)
    bad = []
    for n in extract_financial_numbers(text):
        if not any(abs(n - v) <= max(tol, abs(v) * 0.0005) for v in verified):
            bad.append(n)
    return bad


def validate_ai_answer(answer: str, ctx: dict) -> ValidationResult:
    res = ValidationResult("ai_answer")
    if not answer or not answer.strip():
        res.errors.append("AI answer is empty.")
        return res
    bad = find_unverified_numbers(answer, ctx)
    if bad:
        res.errors.append(f"AI answer contains numbers not present in verified data: {bad}")
    return res


# ------------------------------- 12. Missing / insufficient data rules
def data_sufficiency(ctx: dict) -> dict[str, str]:
    """Per-module availability used by web to choose what to render."""
    def ok(items): return any(i.get("isVerified") for i in items or [])
    return {
        "financialHealth": "available" if ctx.get("healthScore") is not None else "missing",
        "spendingPatterns": "available" if ok(ctx.get("spendingPatterns")) else "missing",
        "anomalies": "available" if ok(ctx.get("anomalies")) else "none",
        "forecast": "available" if ok(ctx.get("forecasts")) else "missing",
        "budgetRecommendations": "available" if ok(ctx.get("budgetRecommendations")) else "missing",
        "recommendations": "available" if ok(ctx.get("recommendations")) else "missing",
    }


def safe_answer(ctx: dict, explain_fn: Callable[[dict], str]) -> dict:
    """
    Gatekeeper used before showing an AI answer on the web.
    - No verified data at all  -> fixed insufficient-data message, AI is NOT called.
    - Otherwise call AI, then reject answers that contain unverified numbers.
    """
    avail = data_sufficiency(ctx)
    if all(v in ("missing", "none") for v in avail.values()):
        return {"answer": INSUFFICIENT_DATA_MESSAGE, "isVerified": False,
                "limitations": ["No verified financial data is available."]}
    answer = explain_fn(ctx)
    check = validate_ai_answer(answer, ctx)
    if not check.is_valid:
        return {"answer": INSUFFICIENT_DATA_MESSAGE, "isVerified": False,
                "limitations": check.errors}
    limits = [ctx["limitations"]] if ctx.get("limitations") else []
    return {"answer": answer, "isVerified": True, "limitations": limits}
