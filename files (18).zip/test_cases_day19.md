# Test Cases — Mobile & Web Testing (Day 19)

**Scope:** End-to-end testing of the AI Dashboard across mobile and web, built on the
verified-data contract from Day 18 (`ai_web_validator.py`). No live deployed
backend was available in this session, so each row is marked with how it was
actually checked — the same honesty convention used in Day 11-14's test docs.

- **Verified** = executed against `test_integration_flows.py` / `test_states.html` in this folder
- **By inspection** = confirmed by reading the Day 17/18 source and this spec together
- **Manual (device)** = needs to be run by hand on a real phone/browser; steps given below

---

## 1-2. AI Dashboard on Mobile / Web

| # | Scenario | Expected behavior | Status |
|---|----------|--------------------|--------|
| 1 | Dashboard loads with full verified data | All 6 module cards render (Health, Spending, Anomaly, Forecast, Budget, Recommendations) | **Verified** — `test_integration_flows.py::test_full_dashboard_renders_all_modules` |
| 2 | Dashboard on a small mobile viewport (360px) | Cards stack vertically, no horizontal scroll, text not clipped | **Manual (device)** — see Section A below |
| 3 | Dashboard on web (desktop width) | Cards can use a grid/multi-column layout | **Manual (device)** |
| 4 | Same verified context on mobile and web | Numbers shown must be identical on both (backend is the single source of truth) | **Verified** — `test_integration_flows.py::test_mobile_and_web_show_same_numbers` |

## 3. Financial Health Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 5 | Score 0-100 present | Score shown as-is, not recalculated | **Verified** — reuses Day 18 `validate_financial_health` |
| 6 | Score out of range (e.g. 140) | Rejected before render; card shows fallback, not the bad number | **Verified** |
| 7 | `savingRate` / `expenseGrowthPercent` null | Those chips are hidden, not shown as 0 or blank | **By inspection** — matches Day 18 mapping table |

## 4. Spending Pattern Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 8 | Normal category with previous amount | Trend badge (Increasing/Decreasing/Stable) + % shown | **Verified** |
| 9 | `previousAmount` null or 0 | % change hidden entirely (never shows "Infinity%" or divide-by-zero) | **Verified** — `test_integration_flows.py::test_spending_pattern_no_previous_amount` |
| 10 | `changePercent` inconsistent with amounts | Row rejected, not displayed | **Verified** |

## 5. Anomaly Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 11 | One or more verified anomalies | Alert badge colored by severity (Low/Medium/High/Critical) | **Verified** |
| 12 | Empty anomaly list | "No unusual activity detected" message, not a blank space | **Verified** — `test_integration_flows.py::test_empty_anomaly_list_message` |
| 13 | Unverified anomaly in the payload | Never rendered, never sent to AI | **Verified** |

## 6. Cash-Flow Forecast Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 14 | Full forecast (income, expense, saving, closing balance) | All fields shown, saving = income - expense | **Verified** |
| 15 | `expectedClosingBalance` null | Card shows "Unavailable" with the reason, not blank/0 | **Verified** |
| 16 | Confidence = Low | UI shows a "Limited history" indicator alongside the numbers | **By inspection** |

## 7. Budget Recommendation Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 17 | Existing budget present | Variance (recommended - existing) shown | **Verified** |
| 18 | No existing budget | Variance hidden; reason text still shown | **Verified** |
| 19 | Data sufficiency = Limited | "Limited data" label shown next to the recommendation | **By inspection** |

## 8. AI Recommendation Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 20 | Verified recommendation list | Rendered with type, reason, action | **Verified** |
| 21 | `expectedBenefit` present but `expectedBenefitVerified = false` | Benefit number hidden | **Verified** — reuses Day 18 `validate_recommendation` |
| 22 | Empty recommendation list | "No recommendations right now" message | **Verified** |

## 9. Priority and Severity Display

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 23 | Mixed priority/severity list | Sorted High→Low priority, then Critical→Low severity (backend order) | **Verified** — reuses Day 18 `validate_priority_order` |
| 24 | Invalid priority/severity value from a bad payload | Row rejected rather than shown with a broken badge | **Verified** |

## 10. Recommendation Detail Screen

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 25 | Tap/click a recommendation card | Detail screen opens showing reason, action, verified amount/percentage if present | **Manual (device)** |
| 26 | Detail screen for a recommendation with no verified amount | Amount/percentage fields simply omitted, not shown as "null" or "N/A" everywhere | **Manual (device)** |
| 27 | Back navigation from detail screen | Returns to the same dashboard scroll position (mobile) | **Manual (device)** |

## 11. Ask HisabDo AI Interface

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 28 | User asks a question, verified data exists | Answer displayed after passing the Day 18 grounding check | **Verified** — `test_integration_flows.py::test_ask_ai_grounded_answer_shown` |
| 29 | AI response contains an invented number | Answer replaced with the safe fallback message, not shown to the user | **Verified** — `test_integration_flows.py::test_ask_ai_hallucination_blocked` |
| 30 | `userId` in request does not match context `userId` | Request rejected (403), no data shown | **By inspection** — matches `HisabDo_Python_Integration_FastAPI.py` |
| 31 | Empty question submitted | Submit disabled / inline validation, no API call made | **Manual (device)** |

## 12-13. Loading and Empty States

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 32 | Dashboard first opens, data not yet returned | Skeleton/spinner shown per card, not a blank white screen | **Manual (device)** — see `test_states.html` "Loading" tab |
| 34 | AI answer being generated | Typing/loading indicator in the Ask HisabDo panel | **Manual (device)** |
| 35 | New user, zero verified data anywhere | Fixed "not enough verified data yet" message; AI is never called | **Verified** — `test_integration_flows.py::test_empty_context_never_calls_ai` |
| 36 | One module has data, others don't | Only the empty modules show their own empty message; populated modules render normally | **Verified** |

## 14. API Error States

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 37 | Backend returns 500/502 | Card shows "Something went wrong" without exposing internal error text | **By inspection** |
| 38 | Backend returns 401/403 | User is prompted to re-authenticate; verified data is never shown from a stale session | **By inspection** |
| 39 | AI service unreachable (network/timeout) | Data cards still render (they don't depend on AI); only the AI panel shows an error | **By inspection** |
| 40 | Malformed JSON from backend | Caught before render; falls back to error state instead of crashing | **Manual (device)** |

## 15. Retry Functionality

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 41 | Retry button after a failed load | Re-fetches the same request; success replaces the error state | **Manual (device)** — see `test_states.html` "Error" tab |
| 42 | Retry after AI hallucination block | Re-asks the same question; does not resend a cached bad answer | **By inspection** |
| 43 | Repeated rapid retry taps | Request is debounced, no duplicate overlapping calls | **Manual (device)** |

## 16. Responsive UI

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 44 | 360px width (small phone) | No horizontal scroll, text wraps, buttons remain tappable (44px+ target) | **Manual (device)** |
| 45 | 768px width (tablet) | Layout adapts, cards may go 2-column | **Manual (device)** |
| 46 | 1280px+ width (desktop) | Dashboard uses available width without over-stretching text lines | **Manual (device)** |
| 47 | Landscape orientation (mobile) | Layout doesn't clip content or lock a fixed portrait height | **Manual (device)** |

## 17. Complete Mobile-to-Backend Flow

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 48 | Mobile app requests dashboard for authenticated user | Backend returns only that user's verified records (Day 17 `MobileAiValidator` rules apply) | **Verified** — `test_integration_flows.py::test_mobile_flow_end_to_end` |
| 49 | Mobile sends a priority/severity value | Backend value used as-is; mobile is confirmed to never recalculate it (per Day 17 comment) | **By inspection** |

## 18. Complete Web-to-Backend Flow

| # | Scenario | Expected | Status |
|---|----------|----------|--------|
| 50 | Web requests dashboard, then asks an AI question in sequence | Both calls use the same verified context; numbers stay consistent across both responses | **Verified** — `test_integration_flows.py::test_web_flow_end_to_end` |
| 51 | Web session refresh mid-flow | New verified context is re-fetched, not reused from stale local state | **Manual (device)** |

## 19. UI / Integration Bugs Found

See `bug_log_day19.md` for the running list and status of each bug found while building/reviewing the above (template ready to fill in as real device/browser testing happens).

---

## A. Manual Device Testing Checklist

Run these by hand once the app is deployed and reachable; check off as completed.

- [ ] iPhone SE / small Android (360-390px) — dashboard, detail screen, Ask HisabDo
- [ ] Standard phone (390-430px) — same three screens
- [ ] Tablet (768px+) — dashboard layout
- [ ] Desktop browser (1280px+) — dashboard layout
- [ ] Chrome + Safari (or the two most-used browsers for this app)
- [ ] Slow/throttled network — confirm loading states appear and don't hang forever
- [ ] Airplane mode mid-session — confirm offline/error state, then confirm retry works when back online

## How the "Verified" rows were actually run

`test_integration_flows.py` builds mock backend responses (using
`sample_verified_context.json` and deliberately-broken variants of it),
runs them through `ai_web_validator.py` (the same module from Day 18),
and asserts what the UI is supposed to do with each result — the same
way `test_client_math.mjs` was used in Day 11-14, minus a live ASP.NET
server. Run with:

```
python -m unittest test_integration_flows -v
```

**Before sign-off:** once the mobile app and web app are pointed at a
live deployed backend, re-run every "Manual (device)" and "By
inspection" row against the real thing — this session only had the
repository source to work from, not a running server.
