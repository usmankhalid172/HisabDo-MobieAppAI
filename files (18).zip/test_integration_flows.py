"""
Day 19 - Mobile & Web Testing: integration-flow tests.

Builds on the Day 18 validation module (ai_web_validator.py) to simulate
the mobile-to-backend and web-to-backend flows and check what the UI is
supposed to do with each result, without needing a live deployed server.

Run:  python -m unittest test_integration_flows -v
"""
import copy
import json
import unittest
from pathlib import Path

import ai_web_validator as v

CTX = json.loads((Path(__file__).parent / "sample_verified_context.json").read_text())

EMPTY_CTX = {
    "userId": "user-002", "recommendations": [], "spendingPatterns": [],
    "anomalies": [], "budgetRecommendations": [], "forecasts": [],
}


def render_dashboard(ctx: dict) -> dict:
    """
    Minimal stand-in for the UI's render step: applies every Day 18
    validator to a context and returns only what a real dashboard would
    end up showing, so tests can assert on that instead of on internals.
    """
    out = {"cards": {}}

    out["cards"]["financialHealth"] = (
        {"score": ctx["healthScore"]}
        if ctx.get("healthScore") is not None and v.validate_financial_health(ctx).is_valid
        else {"empty": "Financial health is not available yet."}
    )

    patterns = [p for p in ctx.get("spendingPatterns", []) if v.validate_spending_pattern(p).is_valid]
    out["cards"]["spendingPatterns"] = patterns or {"empty": "No spending pattern data yet."}

    anomalies = [a for a in ctx.get("anomalies", []) if v.validate_anomaly(a).is_valid]
    out["cards"]["anomalies"] = anomalies if anomalies else {"empty": "No unusual activity detected."}

    forecasts = [f for f in ctx.get("forecasts", []) if v.validate_forecast(f).is_valid]
    out["cards"]["forecasts"] = forecasts or {"empty": "No forecast available yet."}

    budgets = [b for b in ctx.get("budgetRecommendations", []) if v.validate_budget_recommendation(b).is_valid]
    out["cards"]["budgetRecommendations"] = budgets or {"empty": "No budget recommendations yet."}

    recs = [r for r in ctx.get("recommendations", []) if v.validate_recommendation(r).is_valid]
    p_rank = {"High": 1, "Medium": 2, "Low": 3}
    s_rank = {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}
    recs = sorted(recs, key=lambda r: (p_rank.get(r["priority"], 9), s_rank.get(r.get("severity"), 9)))
    out["cards"]["recommendations"] = recs if recs else {"empty": "No recommendations right now."}

    return out


def ask_hisabdo(ctx: dict, question: str, ai_fn) -> dict:
    """Stand-in for the Ask HisabDo panel: gate every AI answer before showing it."""
    return v.safe_answer(ctx, lambda c: ai_fn(question, c))


def grounded_ai(question: str, ctx: dict) -> str:
    return (f"Your financial health score is {ctx['healthScore']}. "
            f"Your saving rate is {ctx['savingRate']}%.")


def hallucinating_ai(question: str, ctx: dict) -> str:
    return "You will have Rs 250,000 saved by next year."


class TestDashboardRendering(unittest.TestCase):
    def test_full_dashboard_renders_all_modules(self):
        d = render_dashboard(CTX)
        self.assertEqual(d["cards"]["financialHealth"]["score"], 58)
        self.assertTrue(d["cards"]["spendingPatterns"])
        self.assertTrue(d["cards"]["anomalies"])
        self.assertTrue(d["cards"]["forecasts"])
        self.assertTrue(d["cards"]["budgetRecommendations"])
        self.assertTrue(d["cards"]["recommendations"])

    def test_mobile_and_web_show_same_numbers(self):
        mobile = render_dashboard(copy.deepcopy(CTX))
        web = render_dashboard(copy.deepcopy(CTX))
        self.assertEqual(mobile, web)

    def test_spending_pattern_no_previous_amount(self):
        ctx = copy.deepcopy(CTX)
        ctx["spendingPatterns"][0]["previousAmount"] = None
        ctx["spendingPatterns"][0]["changePercent"] = None
        d = render_dashboard(ctx)
        self.assertIsNone(d["cards"]["spendingPatterns"][0]["changePercent"])

    def test_empty_anomaly_list_message(self):
        ctx = copy.deepcopy(CTX)
        ctx["anomalies"] = []
        d = render_dashboard(ctx)
        self.assertEqual(d["cards"]["anomalies"], {"empty": "No unusual activity detected."})


class TestEmptyAndMissingData(unittest.TestCase):
    def test_empty_context_never_calls_ai(self):
        called = []
        out = ask_hisabdo(EMPTY_CTX, "How am I doing?", lambda q, c: called.append(1) or "x")
        self.assertEqual(called, [])
        self.assertFalse(out["isVerified"])

    def test_one_module_missing_others_render(self):
        ctx = copy.deepcopy(CTX)
        ctx["forecasts"] = []
        d = render_dashboard(ctx)
        self.assertEqual(d["cards"]["forecasts"], {"empty": "No forecast available yet."})
        self.assertTrue(d["cards"]["spendingPatterns"])  # unaffected


class TestAskHisabDoInterface(unittest.TestCase):
    def test_ask_ai_grounded_answer_shown(self):
        out = ask_hisabdo(CTX, "Why is my score low?", grounded_ai)
        self.assertTrue(out["isVerified"])

    def test_ask_ai_hallucination_blocked(self):
        out = ask_hisabdo(CTX, "How much will I save?", hallucinating_ai)
        self.assertFalse(out["isVerified"])
        self.assertEqual(out["answer"], v.INSUFFICIENT_DATA_MESSAGE)


class TestEndToEndFlows(unittest.TestCase):
    def test_mobile_flow_end_to_end(self):
        """Mobile: fetch dashboard for authenticated user -> render -> no recalculation."""
        ctx = copy.deepcopy(CTX)
        dashboard = render_dashboard(ctx)
        # Mobile must show the backend priority/severity untouched.
        first_rec = dashboard["cards"]["recommendations"][0]
        self.assertEqual(first_rec["priority"], CTX["recommendations"][0]["priority"])
        self.assertEqual(first_rec["severity"], CTX["recommendations"][0]["severity"])

    def test_web_flow_end_to_end(self):
        """Web: fetch dashboard, then ask a question — numbers must stay consistent."""
        ctx = copy.deepcopy(CTX)
        dashboard = render_dashboard(ctx)
        answer = ask_hisabdo(ctx, "Why is my score low?", grounded_ai)
        dashboard_score = dashboard["cards"]["financialHealth"]["score"]
        self.assertIn(str(dashboard_score), answer["answer"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
