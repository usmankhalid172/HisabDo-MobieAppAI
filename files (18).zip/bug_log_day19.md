# Bug Log — Mobile & Web Testing (Day 19)

Running log of UI/integration bugs found while testing. Fill in the
"Found in" and "Status" columns as real device/browser testing happens.
Severity uses the same Low/Medium/High/Critical scale as the app itself.

| # | Area | Bug | Severity | Found in | Status |
|---|------|-----|----------|----------|--------|
| 1 | Day 17 mobile validator | `ContainsUnverifiedFinancialNumber` always returns `false` — cannot actually block a hallucinated number on the mobile side | High | Code review | Fixed in `ai_web_validator.py` (Day 18); needs porting into the mobile validator itself |
| 2 | AI endpoint schema | Deployed `/api/explain` (main.py) uses a company-finance payload, not the personal-finance schema the web/mobile UI needs | High | Code review | Open — flagged to team |
| 3 | Anomaly vs Recommendation severity | Anomaly severity has 3 levels (Low/Medium/High), recommendation severity has 4 (adds Critical) — UI must handle both without crashing on the missing level | Medium | Code review | Open — UI should treat missing severity as Low, not crash |
| 4 | Budget sufficiency naming | `BudgetAnalysisService` returns `insufficient_data`/`ready`; `BudgetRecommendationService` returns `Limited`/`Sufficient` — two different vocabularies for the same concept | Low | Code review | Open — needs one agreed set of values from backend team |
| 5 | | | | | |
| 6 | | | | | |

## How to add a bug

1. Reproduce it against the live app (mobile or web).
2. Note exact steps, screenshot if possible.
3. Check severity against how the recommendation engine defines it (Low/Medium/High/Critical) for consistency.
4. Add a row here before reporting on ClickUp, so the report and the log always match.
