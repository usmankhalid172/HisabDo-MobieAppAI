# HisabDo Backend — AI API Reference (Day 20 finalization)

Single source of truth for every AI-related route: what exists, its auth
rule, and its real status. Replaces checking scattered per-day PDFs.

Legend: ✅ Ready · ⚠️ Present, needs review · ❌ Missing

| API | Method & Route | Auth | Status | Notes |
|---|---|---|---|---|
| Financial Health | — | — | ❌ Missing | No controller or service found in repo |
| Spending Pattern | — | — | ❌ Missing | Service exists (3 duplicate files), no controller |
| Anomaly Detection | `GET /api/ai/anomalies/{userId}` | JWT + claim-vs-route match | ⚠️ Needs review | In-memory demo data; no catch-all error handler |
| Cash-Flow Forecast | `POST /api/forecasting` | JWT + body userId match | ✅ Ready (pending real DB) | Best error-handling coverage in the repo |
| Budget Analysis | `POST /api/budgets/analysis` | JWT + body userId match | ✅ Ready (pending real DB) | |
| Budget Recommendation | `GET /api/ai/budget-recommendations/{userId}` | JWT + claim-vs-route match | ⚠️ Needs review | Duplicate service file exists elsewhere, unused |
| Recommendation Engine | `POST /api/recommendations` | JWT + body userId match | ⚠️ Needs review | Wired engine differs from the documented Day 16 engine — team decision needed |
| Ask HisabDo AI (.NET) | `POST /api/ai/context` | JWT + body userId match | ⚠️ Needs review | Builds context only; does not call the LLM itself |
| Ask HisabDo AI (Python) | `POST /api/ai/explain` | None found | ⚠️ Needs review | Personal-finance schema; not the same as the deployed `/api/explain` |
| Ask HisabDo AI (deployed) | `POST /api/explain` | None found | ⚠️ Needs review | Company-finance payload; wrong schema for this app — see Bug #2 |
| Health check | `GET /health` | None (public) | ✅ Ready | Tested in `tests/test_health.py` |

## Common Request Shape (authenticated endpoints)

All `[Authorize]` endpoints expect a bearer JWT with either
`ClaimTypes.NameIdentifier` or a `sub` claim equal to the `userId` in the
request body or route. A mismatch returns `401 Unauthorized` with:

```json
{ "error": "An authenticated user ID matching the requested userId is required." }
```

## Common Error Responses

| Status | Meaning | Returned by |
|---|---|---|
| 400 | Validation error (bad date range, malformed GUID, etc.) | All controllers |
| 401 | Auth claim missing or doesn't match requested user | All controllers |
| 502 | Forecasting engine failed internally | ForecastingController only |
| 503 | Underlying data could not be loaded | Forecasting, BudgetAnalysis, AskHisabDo controllers |
| 500 (unhandled) | Any exception not explicitly caught | Every controller — no global handler yet, see Day 20 report Section 14 |

## Known Data-Contract Gaps (fix before wiring to mobile/web validators)

1. Response DTOs (`AnomalyAlertsResponse`, `BudgetRecommendationResponse`, etc.) do not currently include an `isVerified` field per record, even though the Day 17/18 mobile/web validation layer expects one on every record.
2. Severity vocabulary differs: Anomaly = Low/Medium/High; Recommendation = Low/Medium/High/Critical.
3. Data-sufficiency vocabulary differs: `insufficient_data`/`ready` (Budget Analysis) vs `Limited`/`Sufficient` (Budget Recommendation).

## Not Yet Connected to a Real Database

Every service currently reads from `DemoAdapters.cs` (in-memory seeded
data). No controller in this repo talks to the actual HisabDo database.
This is the top blocker for MVP delivery — see Day 20 report Section 13.
