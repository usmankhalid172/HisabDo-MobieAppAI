"""
Day 20 - Backend Finalization: API smoke test.

Ready-to-run against a live deployment once one exists. Checks every
route in BACKEND_API_REFERENCE.md for: correct status codes, auth
enforcement, and (where possible) response shape.

Usage:
    BASE_URL=https://your-backend.example.com \
    JWT_TOKEN=eyJhbGciOi... \
    USER_ID=11111111-1111-1111-1111-111111111111 \
    python api_smoke_test.py

Only standard library is used (urllib), so no install step is needed.
Every check prints PASS/FAIL/SKIP; nothing is asserted with exit-code
failure so the whole suite always finishes and reports a full summary.
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from datetime import date, timedelta

BASE_URL = os.environ.get("BASE_URL", "").rstrip("/")
JWT_TOKEN = os.environ.get("JWT_TOKEN", "")
USER_ID = os.environ.get("USER_ID", "")

results: list[tuple[str, str, str]] = []  # (name, PASS/FAIL/SKIP, detail)


def record(name, ok, detail=""):
    results.append((name, "PASS" if ok else "FAIL", detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))


def skip(name, reason):
    results.append((name, "SKIP", reason))
    print(f"[SKIP] {name} — {reason}")


def call(method: str, path: str, auth: bool = True, body: dict | None = None):
    url = f"{BASE_URL}{path}"
    headers = {"Content-Type": "application/json"}
    if auth and JWT_TOKEN:
        headers["Authorization"] = f"Bearer {JWT_TOKEN}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except Exception:
            return e.code, {}
    except Exception as e:
        return None, {"exception": str(e)}


def main():
    if not BASE_URL:
        print("Set BASE_URL to run this against a live server. Nothing to do offline.")
        return

    # 1. Health check — public, no auth
    status, _ = call("GET", "/health", auth=False)
    record("GET /health returns 200", status == 200, f"got {status}")

    if not JWT_TOKEN or not USER_ID:
        skip("All authenticated routes", "set JWT_TOKEN and USER_ID to run these")
    else:
        today = date.today()
        start = (today - timedelta(days=90)).isoformat()

        # 2. Cash-Flow Forecast
        status, body = call("POST", "/api/forecasting", body={
            "UserId": USER_ID, "From": start, "To": today.isoformat(),
            "Frequency": 0, "ForecastPeriods": 1,
        })
        record("POST /api/forecasting returns 200/400/503", status in (200, 400, 503), f"got {status}")

        # 3. Budget Analysis
        status, body = call("POST", "/api/budgets/analysis", body={
            "UserId": USER_ID, "From": start, "To": today.isoformat(),
        })
        record("POST /api/budgets/analysis returns 200/400/503", status in (200, 400, 503), f"got {status}")

        # 4. Anomaly Detection
        status, body = call("GET", f"/api/ai/anomalies/{USER_ID}?startDate={start}&endDate={today.isoformat()}")
        record("GET /api/ai/anomalies/{userId} returns 200/400", status in (200, 400), f"got {status}")
        if status == 200:
            record("Anomaly response has 'Anomalies' field", "Anomalies" in body, str(list(body.keys())))

        # 5. Budget Recommendation
        status, body = call("GET", f"/api/ai/budget-recommendations/{USER_ID}")
        record("GET /api/ai/budget-recommendations/{userId} returns 200/400", status in (200, 400), f"got {status}")

        # 6. Recommendation Engine
        status, body = call("POST", "/api/recommendations", body={
            "UserId": USER_ID, "From": start, "To": today.isoformat(),
        })
        record("POST /api/recommendations returns 200/400/503", status in (200, 400, 503), f"got {status}")

        # 7. Financial Health — expected to be missing per Day 20 audit
        status, _ = call("GET", f"/api/ai/financial-health/{USER_ID}")
        if status == 404:
            skip("GET /api/ai/financial-health/{userId}", "confirmed missing (404) — matches Day 20 audit finding")
        else:
            record("Financial Health route exists", status is not None and status != 404, f"got {status}")

        # 8. Spending Pattern — expected to be missing per Day 20 audit
        status, _ = call("GET", f"/api/ai/spending-pattern/{USER_ID}")
        if status == 404:
            skip("GET /api/ai/spending-pattern/{userId}", "confirmed missing (404) — matches Day 20 audit finding")
        else:
            record("Spending Pattern route exists", status is not None and status != 404, f"got {status}")

        # 9. Auth enforcement — call one endpoint with no token, expect 401
        status, _ = call("POST", "/api/forecasting", auth=False, body={
            "UserId": USER_ID, "From": start, "To": today.isoformat(),
        })
        record("Unauthenticated request is rejected (401)", status == 401, f"got {status}")

    print("\n--- Summary ---")
    passed = sum(1 for _, s, _ in results if s == "PASS")
    failed = sum(1 for _, s, _ in results if s == "FAIL")
    skipped = sum(1 for _, s, _ in results if s == "SKIP")
    print(f"{passed} passed, {failed} failed, {skipped} skipped")


if __name__ == "__main__":
    main()
