# Backend Bug Log — Day 20 Finalization

Consolidated from Day 18/19 findings plus new issues found while auditing
every controller for this task. Severity uses the app's own Low/Medium/
High/Critical scale.

| # | Bug | Area | Severity | Found in | Status |
|---|---|---|---|---|---|
| 1 | Financial Health API has no controller or route | Missing API | Critical | Day 20 audit | Open — top MVP blocker |
| 2 | Spending Pattern API has no controller; 3 duplicate service files exist instead | Missing API | Critical | Day 20 audit | Open — top MVP blocker |
| 3 | No controller connects to a real database; everything runs on in-memory demo data | Data layer | Critical | Day 20 audit | Open — top MVP blocker |
| 4 | Two different Recommendation engines exist (`Forecasting.RecommendationService` wired, Day 16 `TahaRecommendationEngine` documented but not wired) | Recommendation API | High | Day 20 audit | Open — needs team decision |
| 5 | Two different Ask HisabDo AI schemas/endpoints exist (company-finance `/api/explain` deployed vs personal-finance `/api/ai/explain`) | AI service | High | Day 18/19 report | Open |
| 6 | `ContainsUnverifiedFinancialNumber` in Day 17 mobile validator always returns `false` | Mobile validation | High | Day 18 report | Open |
| 7 | No global/catch-all exception handler in any controller — unexpected errors return raw 500 with stack trace | Error handling | Medium | Day 20 audit | Open |
| 8 | Response DTOs don't include `isVerified` per record, but the mobile/web validation layer (Day 18/19) expects it | Data contract | Medium | Day 20 audit | Open |
| 9 | Anomaly severity (3 levels) vs Recommendation severity (4 levels) mismatch | Data contract | Medium | Day 18/19 report | Open |
| 10 | Budget sufficiency naming differs between two services (`insufficient_data`/`ready` vs `Limited`/`Sufficient`) | Data contract | Low | Day 18/19 report | Open |
| 11 | Duplicate Day 14 budget service files (class-based vs record-based, same concepts) | Repo hygiene | Low | Day 20 audit | Open |

## Fix priority for MVP

1. Bugs #1-3 (Critical) — block delivery entirely, need new work not just fixes.
2. Bugs #4-6 (High) — need a decision + a small amount of wiring, not new logic.
3. Bugs #7-11 — can ship after MVP if time-constrained, but should be logged as known issues.
